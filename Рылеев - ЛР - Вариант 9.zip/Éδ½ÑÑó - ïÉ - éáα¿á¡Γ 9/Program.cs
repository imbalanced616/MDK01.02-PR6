﻿Console.Write("Введите количество значений в массиве: ");
int n = Convert.ToInt32(Console.ReadLine());
int[] m = new int[n];
Console.Write($"Последовательность от 1 до {n}: ");
for (int i = 1;
    i <= n;
    i++)
{
    m[i - 1] = i;
    Console.Write(m[i - 1] + " ");
}
Console.WriteLine();
Console.Write("Введите цифру, по концу которой будет суммироваться члены последовательности: ");
int l = Convert.ToInt32(Console.ReadLine());
int sum = m.Where(x => x % 10 == l).Sum();
Console.WriteLine($"Сумма {m.Where(x => x % 10 == l).Count()} членов последовательности, которые оканчиваются на {l}: " + sum);
Console.ReadKey();